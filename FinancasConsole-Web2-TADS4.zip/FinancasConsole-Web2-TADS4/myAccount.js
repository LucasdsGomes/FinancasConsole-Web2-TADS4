const fs = require("fs");
const path = require("path");

const chalk = require("chalk");
const inquirer = require("inquirer");

let monetario = 0

var caminhoUsuario;
var usuario;

var voltarMenuPrincipal;

function run(username, funcaoMenuPrincipal) {
  const caminho = path.join("contas", username + ".json");

  if (fs.existsSync(caminho)) {
    caminhoUsuario = caminho;
    usuario = username;
    voltarMenuPrincipal = funcaoMenuPrincipal;
    dashboard();
  } else {
    throw new Exception("Usuário não existe!");
  }
}

function dashboard() {
  inquirer
    .prompt([
      {
        type: "list",
        name: "opcao",
        message: "Selecione a opção desejada:",
        choices: ["Consultar Saldo", "Depositar", "Sacar", "Sair"],
      },
    ])
    .then((respostas) => {
      const resp = respostas["opcao"];

      if (resp === "Consultar Saldo") {
        consultaSaldo();
      } else if (resp === "Depositar") {
        deposita();
      } else if (resp === "Sacar") {
        saca();
      } else {
        voltarMenuPrincipal();
      }
    })
    .catch((err) => {
      console.log(err);
      voltarMenuPrincipal();
    });
}

function consultaSaldo() {
  console.log("### Consultando saldo ###");

  console.log(chalk.bgGreen.white(`Você tem um total de ${monetario}`))

  dashboard()

  //Programe a operação de consulta de saldo aqui
  /*Não esqueça de invocar a função dashboard() após a execução
  da operação para o usuário poder continuar operando sua conta; */
}

function deposita() {
  console.log("### Depositando ###");
  inquirer
  .prompt([
    {
      type: "number",
      name: "deposito",
      message:
        "Informe a quantidade de dinheiro a ser depositado (somente números):",
    },
  ])
  .then((respostas) => {
    const deposito = respostas["deposito"];

    if (!deposito) {
      console.log(chalk.bgRed.black("Informe a quantidade!"));
      return;
    } else {
      monetario = monetario + deposito
    }

   

    dashboard()
  })
  .catch((err) => console.log(err));
}

function saca() {
  console.log("### Sacando ###");

  inquirer
  .prompt([
    {
      type: "number",
      name: "saque",
      message:
        "Informe a quantidade de dinheiro a ser sacado (somente números):",
    },
  ])
  .then((respostas) => {
    const saque = respostas["saque"];

    if (!saque) {
      console.log(chalk.bgRed.black("Informe a quantidade!"));
      return;
    } else if (saque > monetario) {
      console.log(chalk.bgRed.black("O saque é maior do que o seu dinheiro atual."))
    } else {
      monetario = monetario - saque
    }

    

    dashboard()
  })
  .catch((err) => console.log(err));


  //Programe a operação de saque aqui
  /*Não esqueça de invocar a função dashboard() após a execução
  da operação para o usuário poder continuar operando sua conta; */
}

module.exports = run;
